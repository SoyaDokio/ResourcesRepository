from django.apps import AppConfig


class DataConfig(AppConfig):
    name = 'DataStorage'
    verbose_name = '数据存储'
