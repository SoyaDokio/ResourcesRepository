# pythonanywhere搭建数据存储服务

+ [搭建过程](https://github.com/rhming/pythonanywhere/blob/main/%E6%90%AD%E5%BB%BA.md)

+ 为腾讯云函数提供数据储存api

+ work.py文件里需配置注册的pythonanywhere的账号密码,用于自动延长web应用和计划任务的停运时间
