# wot-data-importer
Load tanks data from World of Tanks to database, used in WoT Tankopedia

## Disclaimer
This code was written when I had little experience with PHP. It's a mess. Sorry

## Installation
1. Create database
2. Import database-structure.sql
3. Update config.php with correct credentials and path to game

## Usage
1. Open /index.php?update=true page in browser (Yes, it's a big mess, I can't even remember why there is update param, but it is required)
2. Wait, it takes some time
3. You have your data
