<?php
// Todo: To be determined by the user.
define('WOT_PATH', 'G:\\Games\\World_of_Tanks\\World_of_Tanks - 9.9 Clean\\'); 
define('MYSQL_HOSTNAME', 'localhost');
define('MYSQL_PORT','3306');
define('MYSQL_USERNAME', 'WoTImportUser');
define('MYSQL_PASSWORD', 'wargaming');
define('MYSQL_DATABASE', 'wot');

//define('LOG_LEVEL','Quiet');
//define('LOG_LEVEL','Minimal');
define('LOG_LEVEL','Normal');
//define('LOG_LEVEL','Detailed');
//define('LOG_LEVEL','Diagnostic');
?>
