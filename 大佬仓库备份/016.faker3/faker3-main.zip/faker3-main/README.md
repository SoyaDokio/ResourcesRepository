## 重要通知
### 落霞与孤鹜齐飞,秋水共长天一色。

Faker维护仓库，收集全网目前能正常使用的脚本。

##  纯净版特色

纯净版去除所有内置助力码，以及切断所有助力池的连接，专注于内部助力。

#### [点击直达频道](https://t.me/pandaqx)

[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=shufflewzc&bg_color=30,e96443,904e95&title_color=fff&text_color=fff)](https://github.com/anuraghazra/github-readme-stats)





【Faker集合仓库纯净版】
ql repo https://ghproxy.com/https://github.com/shufflewzc/faker3.git "jd_|jx_|gua_|jddj_|getJDCookie" "activity|backUp" "^jd[^_]|USER|function|utils|sendNotify|ZooFaker_Necklace.js|JDJRValidator_|sign_graphics_validate|ql|JDSignValidator"

【QX系列教程】
https://www.notion.so/Quantumult-X-cd78c6ab616e4ebf947519b2dd690a0c

【青龙系列教程】
https://www.notion.so/Cent-OS-7-6-1c598629675145988b43a37998a1604a


维护收集不易，各位看官高兴可打赏下~

![image](https://user-images.githubusercontent.com/15306294/140888333-901cbcdd-e599-44c4-b834-8ea4d1ebc7b0.png)


## Special statement:

* Any unlocking and decryption analysis scripts involved in the Script project released by this warehouse are only used for testing, learning and research, and are forbidden to be used for commercial purposes. Their legality, accuracy, completeness and effectiveness cannot be guaranteed. Please make your own judgment based on the situation. .

* All resource files in this project are forbidden to be reproduced or published in any form by any official account or self-media.

* This warehouse is not responsible for any script problems, including but not limited to any loss or damage caused by any script errors.

* Any user who indirectly uses the script, including but not limited to establishing a VPS or disseminating it when certain actions violate national/regional laws or related regulations, this warehouse is not responsible for any privacy leakage or other consequences caused by this.

* Do not use any content of the Script project for commercial or illegal purposes, otherwise you will be responsible for the consequences.

* If any unit or individual believes that the script of the project may be suspected of infringing on their rights, they should promptly notify and provide proof of identity and ownership. We will delete the relevant script after receiving the certification document.

* Anyone who views this item in any way or directly or indirectly uses any script of the Script item should read this statement carefully. This warehouse reserves the right to change or supplement this disclaimer at any time. Once you have used and copied any relevant scripts or rules of the Script project, you are deemed to have accepted this disclaimer.

 **You must completely delete the above content from your computer or mobile phone within 24 hours after downloading.**  </br>
> ***You have used or copied any script made by yourself in this warehouse, it is deemed to have accepted this statement, please read it carefully*** 


## Special thanks to:


* [@NobyDa](https://github.com/NobyDa)
* [@chavyleung](https://github.com/chavyleung)
* [@liuxiaoyucc](https://github.com/liuxiaoyucc)
* [@Zero-S1](https://github.com/Zero-S1)
* [@uniqueque](https://github.com/uniqueque)
* [@nzw9314](https://github.com/nzw9314)
* [@Andy Woo](https://t.me/update_help_group)「青龙互助研究院支持」
* [@Oreo](https://github.com/Oreomeow) 「青龙Faker仓库一键安装配置」

# 欢迎Pull Request！
