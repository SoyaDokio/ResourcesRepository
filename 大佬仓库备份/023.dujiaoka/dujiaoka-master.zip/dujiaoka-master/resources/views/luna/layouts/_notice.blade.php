<div class="notice layui-hide-xs">
    <p class="tit">{{ __('dujiaoka.site_announcement') }}:</p>
    <div class="tips">{!! dujiaoka_config_get('notice') !!}</div>
</div>
