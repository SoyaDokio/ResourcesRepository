package core

import "net/http"

func init() {

}

var Transport *http.Transport
