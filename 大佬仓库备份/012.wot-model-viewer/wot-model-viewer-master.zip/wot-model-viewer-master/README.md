# wot-model-viewer
Online World of Tanks model viewer

## Importing data
1. Import models, as said in import folder
2. Copy gui.pkg/gui/maps/icons/vehicle/contour/* to images/imgContour/*

## Requirements
You will need to somehow list tanks and their respective ident strings, as listed inside tanks.php. You can use wot-data-importer.
