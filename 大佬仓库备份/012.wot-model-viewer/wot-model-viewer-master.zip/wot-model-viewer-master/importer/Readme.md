### How to use ###
1. Unpack all vehicle packages into upnacked folder
2. Run convert-tanks.py
3. Unpacked models are in models folder. Copy them to the website root.