<?php
namespace Loader\Storage;

class None
{
	public function getRelator() {
		return null;
	}
}