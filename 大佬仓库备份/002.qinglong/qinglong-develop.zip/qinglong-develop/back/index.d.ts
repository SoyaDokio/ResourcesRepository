declare namespace Express {
  interface Request {
    platform: 'desktop' | 'mobile';
  }
}
