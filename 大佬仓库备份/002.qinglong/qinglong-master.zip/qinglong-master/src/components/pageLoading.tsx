import { PageLoading } from '@ant-design/pro-layout';

const NewPageLoading = () => {
  return <PageLoading delay={1}></PageLoading>;
};

export default NewPageLoading;
