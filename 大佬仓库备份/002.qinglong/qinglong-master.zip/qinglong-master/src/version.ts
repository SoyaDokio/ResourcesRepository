export const version = '2.11.0';
export const changeLogLink = 'https://t.me/jiao_long/254';
export const changeLog = `2.11.0 版本说明
1. 使用sqlite替换nedb，增加数据库稳定性
2. 任务添加标签功能，感谢https://github.com/kilo5hz
3. 支持自定义bot仓库，感谢https://github.com/chiupam
5. 其他bug修复
`;
