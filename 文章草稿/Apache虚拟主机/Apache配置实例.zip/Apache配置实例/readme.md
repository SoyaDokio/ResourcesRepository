Apache VirtualHost的配置，用以将一个VPS通过多个子域名虚拟为多台主机


注意，这里本来还想配置tomcat结合到apache，以实现JSP+静态，结果未成功。
